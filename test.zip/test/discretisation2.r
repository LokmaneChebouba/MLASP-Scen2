#Rscript discretisation2.r



##############
# TriKmeans
##############

data<-read.table("scoringData-key-postChallengeRelease.csv", sep=",", h=T, row.names=1)
data2<-data[,1:231]
data<-data2



# remplacement des NA par moyenne
for (colonne in 1:ncol(data)){
	for (ligne in 1:nrow(data)){
		if(is.na(data[ligne,colonne])){
			moyenne=colMeans(data,na.rm=T)[colonne]
			data[ligne,colonne]=moyenne
		}

}
}

data_result_noeud<-matrix(0, ncol=ncol(data), nrow=nrow(data))
data_result_patient<-matrix(0, ncol=ncol(data), nrow=nrow(data))
data_result_total<-matrix(0, ncol=ncol(data), nrow=nrow(data))


colnames(data_result_noeud)=colnames(data)
colnames(data_result_patient)=colnames(data)
colnames(data_result_total)=colnames(data)
rownames(data_result_noeud)=rownames(data)
rownames(data_result_patient)=rownames(data)
rownames(data_result_total)=rownames(data)

# proteines/noeuds # 
for (colonne in 1:ncol(data)){

	result_local=kmeans(data[,colonne], centers=2)$cluster
	moyenne1=mean(data[,colonne][result_local==1])
	moyenne2=mean(data[,colonne][result_local==2])
	if(moyenne1>moyenne2){
	data_result_noeud[,colonne][result_local==1]=1
	}
	else{

	data_result_noeud[,colonne][result_local==2]=1
	}
	}

# patients 
for (ligne in 1:nrow(data)){

	result_local=kmeans(t(data[ligne,]), centers=2)$cluster
	moyenne1=mean(t(data[ligne,])[result_local==1])
	moyenne2=mean(t(data[ligne,])[result_local==2])
	if(moyenne1>moyenne2){
	data_result_patient[ligne,][result_local==1]=1
	}
	else{
	data_result_patient[ligne,][result_local==2]=1
	}
	}




# discretisation totale

#creation matrice de discrétisation linéarisée
	matrice_temp<-matrix(0, ncol=ncol(data)*nrow(data), nrow=1)
	for (ligne in 1:nrow(data)){
		debut=(ligne-1)*ncol(data)+1
		fin=(ligne)*ncol(data)
		matrice_temp[1,c(debut:fin)]<-t(data[ligne,])

	}
# kmean sur toutes les données
cluster=kmeans(t(matrice_temp),2)$cluster
moyenne1=mean(t(matrice_temp)[cluster==1])
moyenne2=mean(t(matrice_temp)[cluster==2])

if(moyenne1>moyenne2){
	cluster[cluster==2]=0
}
if(moyenne2>moyenne1){
cluster[cluster==1]=0
cluster[cluster==2]=1
}


# recuperation des valeurs
for (ligne in 1:nrow(data)){
		debut=(ligne-1)*ncol(data)+1
		fin=(ligne)*ncol(data)
		data_result_total[ligne,]<-cluster[(debut:fin)]

	}

write.table(t(data_result_total), "Trikmeans_testing.csv", row.names=T, col.names=T, sep=",", quote=F)
