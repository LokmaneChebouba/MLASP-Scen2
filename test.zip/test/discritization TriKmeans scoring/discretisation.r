

data<-read.table("scoringData-release.csv", sep=",", h=T, row.names=1)
data2<-data[,18:266]

moyenne<-colMeans(data2, na.rm=T)
data_result<-matrix(0, ncol=ncol(data2), nrow=nrow(data2))
# attribution de la moyenne aux données manquantes

# par la moyenne => NUL !!!
for (colonne in 1:ncol(data2)){

	for (ligne in 1:nrow(data2)){
		# si manquantes
		if(is.na(data2[ligne,colonne])){
		data2[ligne,colonne]=moyenne[colonne]

		}
		if(data2[ligne,colonne] > moyenne[colonne]){
			data_result[ligne,colonne]=1
		}
		if(data2[ligne,colonne] < moyenne[colonne]){
			data_result[ligne,colonne]=-1
		}
		}
}



# remplacement des NA par moyenne
for (colonne in 1:ncol(data2)){
	for (ligne in 1:nrow(data2)){
		if(is.na(data2[ligne,colonne])){
			moyenne=colMeans(data2,na.rm=T)[colonne]
			data2[ligne,colonne]=moyenne
		}

}
}


colnames(data_result)<-colnames(data2)
rownames(data_result)<-rownames(data2)

# Par les Kmeans => plus adapté

# pour chaque gene
for (colonne in 1:ncol(data2)){

	result_local=kmeans(data2[,colonne], centers=2)$cluster
	moyenne1=mean(data2[,colonne][result_local==1])
	moyenne1
	moyenne2=mean(data2[,colonne][result_local==2])
	if(moyenne1>moyenne2){
	data_result[,colonne][result_local==1]=1
	}
	else{

	data_result[,colonne][result_local==2]=1
	}
	}

write.table(t(data_result), "discretisation.csv", row.names=T, col.names=T, sep=",", quote=F)




##############
# Double Standardisation
##############
data<-read.table("scoringData-release.csv", sep=",", h=T, row.names=1)
data2<-data[,41:266]
data<-data2



# remplacement des NA par moyenne
for (colonne in 1:ncol(data)){
	for (ligne in 1:nrow(data)){
		if(is.na(data[ligne,colonne])){
			moyenne=colMeans(data,na.rm=T)[colonne]
			data[ligne,colonne]=moyenne
		}

}
}






# standardiser les patient, puis les genes et faire la moyenne des deux
data_result_noeud<-matrix(0, ncol=ncol(data), nrow=nrow(data))
data_result_patient<-matrix(0, ncol=ncol(data), nrow=nrow(data))

colnames(data_result_noeud)=colnames(data)
colnames(data_result_patient)=colnames(data)
rownames(data_result_noeud)=rownames(data)
rownames(data_result_patient)=rownames(data)


# proteines/noeuds # 
for (colonne in 1:ncol(data)){
	jeu_donnees=data[,colonne]
	min=min(jeu_donnees)
	max=max(jeu_donnees)
	nouveaujeu=(jeu_donnees-min(jeu_donnees))/(max(jeu_donnees)-min(jeu_donnees))
	data_result_noeud[,colonne]=nouveaujeu
	}



# patients 
for (ligne in 1:nrow(data)){
	jeu_donnees=data[ligne,]
	min=min(jeu_donnees)
	max=max(jeu_donnees)
	nouveaujeu=(jeu_donnees-min(jeu_donnees))/(max(jeu_donnees)-min(jeu_donnees))
	data_result_patient[ligne,]=t(nouveaujeu)
	}

# moyenne des deux
data_result=(data_result_noeud+data_result_patient)/2
write.table(t(data_result), "discretisation_Trikmeans.csv", row.names=T, col.names=T, sep=",", quote=F)





##############
# TriKmeans
##############

data<-read.table("scoringData-release.csv", sep=",", h=T, row.names=1)
data2<-data[,41:266]
data<-data2



# remplacement des NA par moyenne
for (colonne in 1:ncol(data)){
	for (ligne in 1:nrow(data)){
		if(is.na(data[ligne,colonne])){
			moyenne=colMeans(data,na.rm=T)[colonne]
			data[ligne,colonne]=moyenne
		}

}
}

data_result_noeud<-matrix(0, ncol=ncol(data), nrow=nrow(data))
data_result_patient<-matrix(0, ncol=ncol(data), nrow=nrow(data))
data_result_total<-matrix(0, ncol=ncol(data), nrow=nrow(data))


colnames(data_result_noeud)=colnames(data)
colnames(data_result_patient)=colnames(data)
colnames(data_result_total)=colnames(data)
rownames(data_result_noeud)=rownames(data)
rownames(data_result_patient)=rownames(data)
rownames(data_result_total)=rownames(data)

# proteines/noeuds # 
for (colonne in 1:ncol(data)){

	result_local=kmeans(data[,colonne], centers=2)$cluster
	moyenne1=mean(data[,colonne][result_local==1])
	moyenne2=mean(data[,colonne][result_local==2])
	if(moyenne1>moyenne2){
	data_result_noeud[,colonne][result_local==1]=1
	}
	else{

	data_result_noeud[,colonne][result_local==2]=1
	}
	}

# patients 
for (ligne in 1:nrow(data)){

	result_local=kmeans(t(data[ligne,]), centers=2)$cluster
	moyenne1=mean(t(data[ligne,])[result_local==1])
	moyenne2=mean(t(data[ligne,])[result_local==2])
	if(moyenne1>moyenne2){
	data_result_patient[ligne,][result_local==1]=1
	}
	else{
	data_result_patient[ligne,][result_local==2]=1
	}
	}




# discretisation totale

#creation matrice de discrétisation linéarisée
	matrice_temp<-matrix(0, ncol=ncol(data)*nrow(data), nrow=1)
	for (ligne in 1:nrow(data)){
		debut=(ligne-1)*ncol(data)+1
		fin=(ligne)*ncol(data)
		matrice_temp[1,c(debut:fin)]<-t(data[ligne,])

	}
# kmean sur toutes les données
cluster=kmeans(t(matrice_temp),2)$cluster
moyenne1=mean(t(matrice_temp)[cluster==1])
moyenne2=mean(t(matrice_temp)[cluster==2])

if(moyenne1>moyenne2){
	cluster[cluster==2]=0
}
if(moyenne2>moyenne1){
cluster[cluster==1]=0
cluster[cluster==2]=1
}


# recuperation des valeurs
for (ligne in 1:nrow(data)){
		debut=(ligne-1)*ncol(data)+1
		fin=(ligne)*ncol(data)
		data_result_total[ligne,]<-cluster[(debut:fin)]

	}


# kmean sur les donnees
# matrice[1,]

data_result=(data_result_noeud+data_result_patient+data_result_total)





# moyenne des deux
data_result=(data_result_noeud+data_result_patient)/2
