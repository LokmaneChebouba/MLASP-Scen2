#source activate caspo-env
#python testing.py

from caspo import core

i=1
while i<101:
	networks1 = core.LogicalNetworkList.from_csv('behaviorscr.csv')
	networks2 = core.LogicalNetworkList.from_csv('behaviorspr.csv')
	dataset1 = core.Dataset('CR/CR_test'+"%s" % i+'.csv', 10)
	dataset2 = core.Dataset('PR/PR_test'+"%s" % i+'.csv', 10)
	#setup = core.Setup.from_json('setup.json')

	msecr=networks1.weighted_mse(dataset1)
	msepr=networks2.weighted_mse(dataset2)
	#print ('msecr'+"%s" % i+'=', msecr)
	#print ('msepr'+"%s" % i+'=', msepr)
	#ouverture en ajout
	f=open('results_test.txt', 'a')
	#f.write('patient number'+str(i)+':')
	#f.write('\n')
	#f.write('msecr= ')
	#f.write (str(msecr))
	#f.write('\n')
	#f.write('msepr= ')
	#f.write (str(msepr))
	#f.write('\n')
	if(msecr<msepr):
		#f.write('prediction pour patient number'+str(i)+'est: Complete Remission')
		f.write('CR')
	else:
		#f.write('prediction pour patient number'+str(i)+'est: Primary Resistant')
		f.write('PR')
		
	#f.write('\n')
	#f.write('===========================')
	#ajouter un saut de ligne
	f.write("\n")
	f.close()
	i+=1
